package za.co.campusfoodordering

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
data class FoodItem(
    val id: Long,
    val name: String,
    val description: String,
    val category: String,
    val price: Double,
    val available: Boolean
)

object FoodApi {
    // Replace this with your real ORDS food_items endpoint.
    // Example: https://your-host/ords/campusfood/food_items/
    private const val FOOD_URL =
        "https://YOUR-ORDS-HOST/ords/campusfood/food_items/"

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun getFoodItems(
        onSuccess: (List<FoodItem>) -> Unit,
        onError: (String) -> Unit
    ) {
        executor.execute {
            var connection: HttpURLConnection? = null

            try {
                connection = URL(FOOD_URL).openConnection()
                        as HttpURLConnection

                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.setRequestProperty(
                    "Accept", "application/json"
                )

                val status = connection.responseCode
                val stream = if (status in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

                val body = stream.bufferedReader().use {
                    it.readText()
                }

                if (status !in 200..299) {
                    throw Exception("HTTP $status: $body")
                }

                val items = parseFoodItems(body)

                mainHandler.post {
                    onSuccess(items)
                }
            } catch (e: Exception) {
                mainHandler.post {
                    onError(e.message ?: "Unable to load menu")
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun parseFoodItems(body: String): List<FoodItem> {
        val trimmed = body.trim()

        val array: JSONArray = if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            val root = JSONObject(trimmed)
            root.optJSONArray("items")
                ?: root.optJSONArray("results")
                ?: JSONArray()
        }

        return buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)

                val id = item.optLong(
                    "food_id",
                    item.optLong("id", 0L)
                )

                val name = item.optString("name", "")
                val price = item.optDouble("price", 0.0)

                val availableValue = item.opt("available")
                val available = when (availableValue) {
                    is Boolean -> availableValue
                    is String -> availableValue.equals("Y", true) ||
                            availableValue.equals("true", true)
                    else -> true
                }

                if (name.isNotBlank()) {
                    add(
                        FoodItem(
                            id = id,
                            name = name,
                            description = item.optString(
                                "description", ""
                            ),
                            category = item.optString(
                                "category", "Other"
                            ),
                            price = price,
                            available = available
                        )
                    )
                }
            }
        }.filter { it.available }
    }
}