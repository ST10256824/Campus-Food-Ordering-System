package za.co.campusfoodordering

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class FoodMenuViewModel : ViewModel() {
    var foodItems by mutableStateOf<List<FoodItem>>(emptyList())
        private set

    var loading by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    fun loadMenu() {
        loading = true
        errorMessage = null

        FoodApi.getFoodItems(
            onSuccess = { items ->
                foodItems = items
                loading = false
            },
            onError = { message ->
                errorMessage = message
                loading = false
            }

        )
    }
}