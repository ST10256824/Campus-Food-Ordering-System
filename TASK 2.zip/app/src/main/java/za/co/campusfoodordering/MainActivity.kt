import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation




private val CampusGreen = Color(0xFF176B4D)
private val LightGreen = Color(0xFFE5F3E9)
private val Cream = Color(0xFFFAF8F1)
private val DarkText = Color(0xFF20352B)

data class FoodItem(
    val id: Int,
    val name: String,
    val description: String,
    val price: Double,
    val category: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CampusFoodApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampusFoodApp() {
    val menu = remember {
        listOf(
            FoodItem(1, "Chicken Burger", "Grilled chicken and fresh salad", 55.0, "Meals"),
            FoodItem(2, "Beef Burger", "Beef patty with cheese", 65.0, "Meals"),
            FoodItem(3, "Chicken Wrap", "Chicken, lettuce and sauce", 45.0, "Meals"),
            FoodItem(4, "Chips", "Golden crispy potato chips", 25.0, "Sides"),
            FoodItem(5, "Toasted Sandwich", "Cheese and tomato", 35.0, "Meals"),
            FoodItem(6, "Chicken Salad", "Fresh vegetables and chicken", 50.0, "Meals"),
            FoodItem(7, "Muffin", "Freshly baked muffin", 18.0, "Snacks"),
            FoodItem(8, "Coffee", "Freshly brewed coffee", 20.0, "Drinks"),
            FoodItem(9, "Fruit Cup", "Seasonal fresh fruit", 22.0, "Snacks"),
            FoodItem(10, "Water", "500 ml bottled water", 12.0, "Drinks")
        )
    }



    val cart = remember { mutableStateMapOf<Int, Int>() }
    var selectedTab by remember { mutableStateOf("Menu") }
    var selectedCategory by remember { mutableStateOf("All") }
    var searchText by remember { mutableStateOf("") }
    var orderMessage by remember { mutableStateOf<String?>(null) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var darkModeEnabled by remember { mutableStateOf(false) }
    var studentNumber by remember { mutableStateOf("") }

    val categories = listOf("All", "Meals", "Sides", "Snacks", "Drinks")
    val itemCount = cart.values.sum()
    val total = menu.sumOf { it.price * (cart[it.id] ?: 0) }

    val filteredMenu = menu.filter { food ->
        (selectedCategory == "All" || food.category == selectedCategory) &&
                (food.name.contains(searchText, ignoreCase = true) ||
                        food.description.contains(searchText, ignoreCase = true) ||
                        food.category.contains(searchText, ignoreCase = true))
    }

    val colors = if (darkModeEnabled) {
        darkColorScheme(
            primary = Color(0xFF8DD6AC),
            secondary = Color(0xFFB8DCC4)
        )
    } else {
        lightColorScheme(
            primary = CampusGreen,
            secondary = Color(0xFF47775D),
            background = Cream,
            surface = Color.White,
            onBackground = DarkText,
            onSurface = DarkText
        )
    }

    MaterialTheme(colorScheme = colors) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "Campus Bites",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 22.sp
                            )
                            Text(
                                "YOUR CAMPUS FOOD STOP",
                                fontSize = 10.sp,
                                letterSpacing = 1.5.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    listOf("Menu", "Cart", "Settings").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Text(
                                    when (tab) {
                                        "Menu" -> "🍽️"
                                        "Cart" -> "🛒"
                                        else -> "⚙️"
                                    },
                                    fontSize = 19.sp
                                )
                            },
                            label = {
                                Text(
                                    if (tab == "Cart" && itemCount > 0)
                                        "Cart ($itemCount)" else tab
                                )
                            }
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "Menu" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .padding(top = 14.dp, bottom = 10.dp)
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (darkModeEnabled)
                                        Color(0xFF254638) else LightGreen
                                ),
                                shape = RoundedCornerShape(22.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp)
                                ) {
                                    Text("HELLO, STUDENT 👋",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.2.sp
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Good food. Easy ordering.",
                                        fontSize = 23.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text("Find your favourite meal between classes.")
                                }
                            }

                            Spacer(Modifier.height(14.dp))

                            OutlinedTextField(
                                value = searchText,
                                onValueChange = { searchText = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                label = { Text("Search meals and drinks") },
                                leadingIcon = { Text("🔎") }
                            )

                            Spacer(Modifier.height(12.dp))

                            Text(
                                "Explore categories",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(Modifier.height(8.dp))

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(categories) { category ->
                                    FilterChip(
                                        selected = selectedCategory == category,
                                        onClick = { selectedCategory = category },
                                        label = { Text(category) }
                                    )
                                }
                            }

                            Spacer(Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Popular on campus",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(Modifier.weight(1f))
                                Text(
                                    "${filteredMenu.size} items",
                                    color = MaterialTheme.colorScheme.secondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = 4.dp,
                                bottom = 20.dp
                            ),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filteredMenu, key = { it.id }) { food ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(18.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface
                                    ),
                                    elevation = CardDefaults.cardElevation(2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(66.dp)
                                                .background(
                                                    if (darkModeEnabled)
                                                        Color(0xFF254638) else LightGreen,
                                                    RoundedCornerShape(16.dp)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(foodEmoji(food), fontSize = 30.sp)
                                        }

                                        Spacer(Modifier.width(12.dp))

                                        Column(
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                food.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                            Spacer(Modifier.height(3.dp))
                                            Text(
                                                food.description,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(Modifier.height(6.dp))
                                            Text(
                                                food.category.uppercase(),
                                                fontSize = 10.sp,
                                                letterSpacing = 1.sp,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                            Spacer(Modifier.height(3.dp))
                                            Text(
                                                money(food.price),
                                                fontSize = 17.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Spacer(Modifier.width(6.dp))
                                        Button(
                                            onClick = {
                                                cart[food.id] =
                                                    (cart[food.id] ?: 0) + 1
                                            },
                                            contentPadding = PaddingValues(
                                                horizontal = 13.dp,
                                                vertical = 9.dp
                                            )
                                        ) {
                                            Text("+ Add")
                                        }
                                    }
                                }
                            }

                            if (filteredMenu.isEmpty()) {
                                item {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("🔎", fontSize = 36.sp)
                                        Text("No matching food found.",
                                            fontWeight = FontWeight.Bold)
                                        Text("Try another search or category.")
                                        TextButton(onClick = {
                                            searchText = ""
                                            selectedCategory = "All"
                                        }) {
                                            Text("Clear filters")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "Cart" -> {
                    val cartItems = menu.filter { (cart[it.id] ?: 0) > 0 }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .padding(horizontal = 16.dp)
                    ) {
                        Spacer(Modifier.height(18.dp))
                        Text("Your cart 🛒",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold)
                        Text("Review your selection before checkout.")
                        Spacer(Modifier.height(14.dp))

                        if (cartItems.isEmpty()) {
                            Spacer(Modifier.height(55.dp))
                            Text(
                                "🛍️",
                                fontSize = 48.sp,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "Your cart is empty",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                            Text(
                                "Add something delicious from the menu.",
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                            Spacer(Modifier.height(16.dp))
                            Button(
                                onClick = { selectedTab = "Menu" },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Browse menu")
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(bottom = 12.dp)
                            ) {
                                items(cartItems, key = { it.id }) { food ->
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(Modifier.padding(14.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(foodEmoji(food), fontSize = 28.sp)
                                                Spacer(Modifier.width(10.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(food.name,
                                                        fontWeight = FontWeight.Bold)
                                                    Text("${money(food.price)} each",
                                                        fontSize = 12.sp)
                                                }
                                                Text(
                                                    money(food.price * (cart[food.id] ?: 0)),
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }

                                            Spacer(Modifier.height(8.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedButton(onClick = {
                                                    val quantity = cart[food.id] ?: 0
                                                    if (quantity <= 1) cart.remove(food.id)
                                                    else cart[food.id] = quantity - 1
                                                }) { Text("−") }

                                                Text(
                                                    "${cart[food.id] ?: 0}",
                                                    modifier = Modifier.padding(horizontal = 16.dp),
                                                    fontWeight = FontWeight.Bold
                                                )

                                                OutlinedButton(onClick = {
                                                    cart[food.id] =
                                                        (cart[food.id] ?: 0) + 1
                                                }) { Text("+") }

                                                Spacer(Modifier.weight(1f))
                                                TextButton(onClick = {
                                                    cart.remove(food.id)
                                                }) { Text("Remove") }
                                            }
                                        }
                                    }
                                }
                            }

                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (darkModeEnabled)
                                        Color(0xFF254638) else LightGreen
                                )
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Items in cart")
                                        Spacer(Modifier.weight(1f))
                                        Text("$itemCount")
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    HorizontalDivider()
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Total",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 19.sp)
                                        Spacer(Modifier.weight(1f))
                                        Text(money(total),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 23.sp,
                                            color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }

                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    if (studentNumber.isBlank()) {
                                        orderMessage =
                                            "Please enter your student number in Settings before placing an order."
                                    } else {
                                        orderMessage =
                                            "Demo order placed for student $studentNumber. Total: ${money(total)}. This demonstration has not saved the order to a server."
                                        cart.clear()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Place demo order", fontSize = 16.sp)
                            }
                            OutlinedButton(
                                onClick = { cart.clear() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp)
                            ) {
                                Text("Clear cart")
                            }
                        }
                    }
                }

                "Settings" -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .horizontalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        // Keep the settings content in a vertically scrollable column.
                        Column(
                            modifier = Modifier.widthIn(min = 280.dp, max = 600.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text("Settings ⚙️",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold)
                            Text("Personalise your Campus Bites experience.")

                            Card(
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Student profile",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = studentNumber,
                                        onValueChange = { studentNumber = it },
                                        label = { Text("Student number") },
                                        placeholder = { Text("Enter your student number") },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Ascii
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Text(
                                        "Used for the demo checkout message only.",
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            Card(
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("App preferences",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp)
                                    Spacer(Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text("Order notifications",
                                                fontWeight = FontWeight.Medium)
                                            Text("Preference only; push notifications are not configured.",
                                                fontSize = 12.sp)
                                        }
                                        Switch(
                                            checked = notificationsEnabled,
                                            onCheckedChange = { notificationsEnabled = it }
                                        )
                                    }
                                    HorizontalDivider()
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text("Dark appearance",
                                                fontWeight = FontWeight.Medium)
                                            Text("Change the app colour theme.",
                                                fontSize = 12.sp)
                                        }
                                        Switch(
                                            checked = darkModeEnabled,
                                            onCheckedChange = { darkModeEnabled = it }
                                        )
                                    }
                                }
                            }

                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (darkModeEnabled)
                                        Color(0xFF254638) else LightGreen
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Campus Bites",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.ExtraBold)
                                    Text("Campus Food Ordering System")
                                    Text("Version 1.0")
                                    Spacer(Modifier.height(6.dp))
                                    Text("Student ordering prototype",
                                        fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        orderMessage?.let { message ->
            AlertDialog(
                onDismissRequest = { orderMessage = null },
                title = { Text("Order status") },
                text = { Text(message) },
                confirmButton = {
                    TextButton(onClick = { orderMessage = null }) {
                        Text("OK")
                    }
                }
            )
        }
    }
}

private fun foodEmoji(food: FoodItem): String {
    return when (food.name) {
        "Chicken Burger", "Beef Burger" -> "🍔"
        "Chicken Wrap" -> "🌯"
        "Chips" -> "🍟"
        "Toasted Sandwich" -> "🥪"
        "Chicken Salad" -> "🥗"
        "Muffin" -> "🧁"
        "Coffee" -> "☕"
        "Fruit Cup" -> "🍓"
        "Water" -> "💧"
        else -> "🍽️"
    }
}

@Composable
fun AuthScreen(
    onSignIn: (String, String) -> Unit,
    onRegister: (String, String) -> Unit
) {
    var isRegistering by remember { mutableStateOf(false) }
    var studentNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAF8F1))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .background(
                    Color(0xFFE5F3E9),
                    RoundedCornerShape(24.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text("🍽️", fontSize = 42.sp)
        }

        Spacer(Modifier.height(16.dp))

        Text(
            "Campus Bites",
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF176B4D)
        )

        Text(
            if (isRegistering) "Create your student account"
            else "Your campus food stop",
            color = Color(0xFF52675A)
        )

        Spacer(Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    if (isRegistering) "Register" else "Welcome back",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF20352B)
                )

                Text(
                    if (isRegistering)
                        "Enter your details to continue."
                    else
                        "Sign in to access the food menu.",
                    fontSize = 14.sp
                )

                OutlinedTextField(
                    value = studentNumber,
                    onValueChange = {
                        studentNumber = it
                        message = null
                    },
                    label = { Text("Student number") },
                    placeholder = { Text("e.g. STU1001") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        message = null
                    },
                    label = { Text("Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (passwordVisible)
                        VisualTransformation.None
                    else PasswordVisualTransformation(),
                    trailingIcon = {
                        TextButton(
                            onClick = {
                                passwordVisible = !passwordVisible
                            }
                        ) {
                            Text(if (passwordVisible) "Hide" else "Show")
                        }
                    }
                )

                if (isRegistering) {
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = {
                            confirmPassword = it
                            message = null
                        },
                        label = { Text("Confirm password") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation()
                    )
                }

                message?.let {
                    Text(
                        it,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp
                    )
                }

                Button(
                    onClick = {
                        when {
                            studentNumber.isBlank() ->
                                message = "Please enter your student number."

                            password.length < 6 ->
                                message = "Password must contain at least 6 characters."

                            isRegistering && password != confirmPassword ->
                                message = "The passwords do not match."

                            isRegistering -> {
                                onRegister(studentNumber.trim(), password)
                            }

                            else -> {
                                onSignIn(studentNumber.trim(), password)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        if (isRegistering) "Create account" else "Sign in",
                        fontSize = 16.sp
                    )
                }

                TextButton(
                    onClick = {
                        isRegistering = !isRegistering
                        message = null
                        confirmPassword = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (isRegistering)
                            "Already registered? Sign in"
                        else
                            "New student? Create an account"
                    )
                }

                HorizontalDivider()

                Text(
                    "Demonstration mode: authentication is not connected to the server yet.",
                    fontSize = 11.sp,
                    color = Color(0xFF69766D)
                )
            }
        }
    }
}

private fun money(amount: Double): String {
    return String.format(Locale("en", "ZA"), "R %.2f", amount)
}